/* =========================================================
   PERFIL PROFESOR — Firestore
   ========================================================= */
import {
  getProfesorDB, actualizarProfesorDB,
  getCursosProfDB, crearCursoDB, actualizarCursoDB, eliminarCursoDB, toggleOcultarCursoDB,
  agregarMaterialDB, eliminarMaterialDB,
  getTodosEstudiantesDB,
  inscribirseDB, desinscribirseDB, getCursosInscritosDB, getInscriptosDeCursooDB
} from '../js/firebase.js';

var sesion = JSON.parse(localStorage.getItem('edutech_sesion') || 'null');
if(!sesion || sesion.rol !== 'profesor') window.location.href = '../auth-profesor/index.html';
var codeSesion = sesion.code;

var _prof = null;
var _cursos = [];
var _estudiantes = [];
var cursoExpandido = null;
var asignarCursoId = null;
var califEstEmail  = null;

/* =========================================================
   INIT
   ========================================================= */
async function init(){
  try {
    _prof = await getProfesorDB(codeSesion);
    if(!_prof){ cerrarSesion(); return; }

    document.getElementById('topNombre').textContent    = _prof.nombre.split(' ')[0];
    document.getElementById('topCode').textContent      = codeSesion;
    document.getElementById('perfilNombre').textContent = _prof.nombre;
    document.getElementById('perfilEmail').textContent  = _prof.email;
    document.getElementById('perfilCode').textContent   = codeSesion;
    document.getElementById('editNombre').value = _prof.nombre;
    document.getElementById('editEmail').value  = _prof.email;
    document.getElementById('editTel').value    = _prof.telefono || '';
    document.getElementById('editCode').value   = codeSesion;

    var partes = _prof.nombre.split(' ');
    var ini = partes.length >= 2 ? partes[0][0]+partes[1][0] : partes[0].substring(0,2);
    document.getElementById('avatarInitials').textContent = ini.toUpperCase();
    if(_prof.foto) mostrarFoto(_prof.foto);

    await cargarCursos();
    await cargarEstudiantes();
  } catch(e){ console.error('Error init:', e); }
}

/* =========================================================
   FOTO
   ========================================================= */
function mostrarFoto(src){
  var img = document.getElementById('avatarImg');
  img.src=src; img.style.display='block';
  document.getElementById('avatarInitials').style.display='none';
}
function subirFoto(input){
  var file=input.files[0]; if(!file) return;
  var reader=new FileReader();
  reader.onload=async function(e){
    mostrarFoto(e.target.result);
    await actualizarProfesorDB(codeSesion, { foto: e.target.result });
  };
  reader.readAsDataURL(file);
}

/* =========================================================
   PERFIL
   ========================================================= */
async function guardarPerfil(){
  var nombre=document.getElementById('editNombre').value.trim();
  if(!nombre){ mostrarMsg('msgPerfil','El nombre no puede estar vacío.','err'); return; }
  await actualizarProfesorDB(codeSesion, { nombre, telefono: document.getElementById('editTel').value.trim() });
  sesion.nombre=nombre;
  localStorage.setItem('edutech_sesion', JSON.stringify(sesion));
  document.getElementById('perfilNombre').textContent=nombre;
  document.getElementById('topNombre').textContent=nombre.split(' ')[0];
  mostrarMsg('msgPerfil','¡Datos actualizados!','ok');
}

async function cambiarPass(){
  var actual=document.getElementById('passActual').value;
  var p1=document.getElementById('passNueva1').value;
  var p2=document.getElementById('passNueva2').value;
  if(_prof.password !== actual){ mostrarMsg('msgPass','Contraseña actual incorrecta.','err'); return; }
  if(p1.length<8){ mostrarMsg('msgPass','Mínimo 8 caracteres.','err'); return; }
  if(p1!==p2){ mostrarMsg('msgPass','Las contraseñas no coinciden.','err'); return; }
  await actualizarProfesorDB(codeSesion, { password: p1 });
  _prof.password=p1;
  document.getElementById('passActual').value='';
  document.getElementById('passNueva1').value='';
  document.getElementById('passNueva2').value='';
  mostrarMsg('msgPass','¡Contraseña actualizada!','ok');
}

/* =========================================================
   CURSOS
   ========================================================= */
async function cargarCursos(){
  _cursos = await getCursosProfDB(codeSesion);
  renderCursos();
}

async function crearCurso(){
  var titulo=document.getElementById('cTitle').value.trim();
  var desc=document.getElementById('cDesc').value.trim();
  var cat=document.getElementById('cCat').value;
  if(!titulo){ mostrarMsg('msgCurso','El título es obligatorio.','err'); return; }
  var id='pc_'+Date.now();
  await crearCursoDB({ id, profCode:codeSesion, profesor:_prof.nombre, titulo, descripcion:desc, categoria:cat, oculto:false, materiales:[] });
  document.getElementById('cTitle').value='';
  document.getElementById('cDesc').value='';
  mostrarMsg('msgCurso','¡Curso creado exitosamente!','ok');
  await cargarCursos();
}

function renderCursos(){
  var el=document.getElementById('cursosLista');
  if(_cursos.length===0){
    el.innerHTML='<div class="empty-state"><div class="empty-ico">📭</div><p>Aún no has creado ningún curso.</p></div>';
    return;
  }
  el.innerHTML=_cursos.map(function(c){
    var mats=(c.materiales||[]).map(function(m){
      var ico=m.tipo==='pdf'?'fa-file-pdf':m.tipo==='video'?'fa-play-circle':'fa-link';
      return '<div class="material-item">'+
        '<i class="fas '+ico+'"></i>'+
        '<span class="mat-name">'+m.nombre+'</span>'+
        '<span class="mat-url">'+m.url+'</span>'+
        '<button class="btn-del-mat" onclick="eliminarMaterial(\''+c.id+'\',\''+m.id+'\')"><i class="fas fa-trash"></i></button>'+
      '</div>';
    }).join('');
    var esOculto=c.oculto===true;
    var ocultoBadge=esOculto?'<span class="badge-oculto"><i class="fas fa-eye-slash"></i> Oculto</span>':'<span class="badge-visible"><i class="fas fa-eye"></i> Visible</span>';
    var btnOcultar=esOculto
      ?'<button class="btn-save btn-visible btn-sm" onclick="event.stopPropagation();toggleOcultar(\''+c.id+'\')"><i class="fas fa-eye"></i> Mostrar</button>'
      :'<button class="btn-save btn-ocultar btn-sm" onclick="event.stopPropagation();toggleOcultar(\''+c.id+'\')"><i class="fas fa-eye-slash"></i> Ocultar</button>';
    return '<div class="curso-prof-card'+(esOculto?' curso-oculto':'')+'">'+
      '<div class="curso-prof-header" onclick="toggleCurso(\''+c.id+'\')">'+
        '<div class="curso-prof-ico">'+(esOculto?'🙈':'📚')+'</div>'+
        '<div class="curso-prof-info"><h4>'+c.titulo+' '+ocultoBadge+'</h4>'+
          '<p>'+c.categoria+' · '+(c.materiales||[]).length+' materiales · '+(c.inscritos||[]).length+' inscritos</p></div>'+
        '<div class="curso-prof-actions">'+btnOcultar+
          '<button class="btn-save btn-blue btn-sm" onclick="event.stopPropagation();abrirAsignar(\''+c.id+'\')"><i class="fas fa-user-plus"></i> Asignar</button>'+
          '<button class="btn-save btn-red btn-sm" onclick="event.stopPropagation();eliminarCurso(\''+c.id+'\')"><i class="fas fa-trash"></i></button>'+
        '</div>'+
      '</div>'+
      '<div class="curso-body-exp" id="exp-'+c.id+'">'+
        '<p style="font-size:.85rem;color:#6b7280;margin-bottom:1rem">'+c.descripcion+'</p>'+
        '<div class="card-title" style="font-size:.9rem"><i class="fas fa-paperclip"></i> Material del curso</div>'+
        (mats||'<p style="font-size:.82rem;color:#9ca3af">Sin materiales aún.</p>')+
        '<div class="add-mat-form">'+
          '<div class="card-title" style="font-size:.85rem;margin-bottom:.7rem"><i class="fas fa-plus"></i> Agregar material</div>'+
          '<div class="add-mat-grid">'+
            '<div class="fg"><label>TIPO</label><select id="mTipo-'+c.id+'"><option value="pdf">PDF</option><option value="video">Video</option><option value="enlace">Enlace</option></select></div>'+
            '<div class="fg"><label>NOMBRE</label><input type="text" id="mNombre-'+c.id+'" placeholder="Nombre del archivo"/></div>'+
            '<div class="fg"><label>URL / ENLACE</label><input type="text" id="mUrl-'+c.id+'" placeholder="https://..."/></div>'+
          '</div>'+
          '<button class="btn-save btn-sm" style="margin-top:.6rem" onclick="agregarMaterial(\''+c.id+'\')"><i class="fas fa-plus" style="margin-right:.3rem"></i>Agregar</button>'+
        '</div>'+
      '</div>'+
    '</div>';
  }).join('');
}

function toggleCurso(id){
  document.getElementById('exp-'+id).classList.toggle('open');
}

async function agregarMaterial(cursoId){
  var tipo=document.getElementById('mTipo-'+cursoId).value;
  var nombre=document.getElementById('mNombre-'+cursoId).value.trim();
  var url=document.getElementById('mUrl-'+cursoId).value.trim();
  if(!nombre||!url){ alert('Completa nombre y URL del material.'); return; }
  await agregarMaterialDB(cursoId, { id:'m_'+Date.now(), tipo, nombre, url });
  await cargarCursos();
  setTimeout(function(){ var el=document.getElementById('exp-'+cursoId); if(el) el.classList.add('open'); },50);
}

async function eliminarMaterial(cursoId, matId){
  if(!confirm('¿Eliminar este material?')) return;
  var curso=_cursos.find(function(c){ return c.id===cursoId; });
  var idx=(curso.materiales||[]).findIndex(function(m){ return m.id===matId; });
  if(idx===-1) return;
  await eliminarMaterialDB(cursoId, idx);
  await cargarCursos();
  setTimeout(function(){ var el=document.getElementById('exp-'+cursoId); if(el) el.classList.add('open'); },50);
}

async function eliminarCurso(cursoId){
  if(!confirm('¿Eliminar este curso? Se perderá todo su material.')) return;
  await eliminarCursoDB(cursoId);
  await cargarCursos();
}

async function toggleOcultar(cursoId){
  var curso=_cursos.find(function(c){ return c.id===cursoId; });
  if(!curso) return;
  await toggleOcultarCursoDB(cursoId, curso.oculto===true);
  await cargarCursos();
}

/* =========================================================
   ASIGNAR ESTUDIANTES
   ========================================================= */
async function abrirAsignar(cursoId){
  asignarCursoId=cursoId;
  var curso=_cursos.find(function(c){ return c.id===cursoId; });
  document.getElementById('asignarCursoNombre').textContent=curso.titulo;
  var inscritos=await getInscriptosDeCursooDB(cursoId);

  document.getElementById('assignList').innerHTML=_estudiantes.length===0
    ?'<p style="font-size:.85rem;color:#9ca3af;text-align:center">No hay estudiantes registrados.</p>'
    :_estudiantes.map(function(e){
      var checked=inscritos.indexOf(e.email)>-1?'checked':'';
      return '<label class="assign-item">'+
        '<input type="checkbox" value="'+e.email+'" '+checked+' class="assign-check"/>'+
        '<span style="font-weight:700;font-size:.88rem">'+e.nombre+'</span>'+
        '<span style="font-size:.78rem;color:#9ca3af">'+e.email+'</span>'+
      '</label>';
    }).join('');
  document.getElementById('modalAsignar').classList.add('open');
}

async function guardarAsignacion(){
  var checks=document.querySelectorAll('.assign-check');
  var inscritos=await getInscriptosDeCursooDB(asignarCursoId);

  for(var i=0;i<checks.length;i++){
    var email=checks[i].value;
    var estabaInscrito=inscritos.indexOf(email)>-1;
    var ahoraChecked=checks[i].checked;
    if(ahoraChecked && !estabaInscrito) await inscribirseDB(asignarCursoId, email);
    if(!ahoraChecked && estabaInscrito) await desinscribirseDB(asignarCursoId, email);
  }
  cerrarModal('modalAsignar');
  await cargarCursos();
}

/* =========================================================
   ESTUDIANTES
   ========================================================= */
async function cargarEstudiantes(){
  _estudiantes=await getTodosEstudiantesDB();
  renderEstudiantes();
}

function renderEstudiantes(){
  var el=document.getElementById('estudiantesLista');
  if(_estudiantes.length===0){
    el.innerHTML='<div class="empty-state"><div class="empty-ico">👥</div><p>Aún no hay estudiantes registrados.</p></div>';
    return;
  }
  el.innerHTML=_estudiantes.map(function(e){
    var ini=e.nombre.split(' ').length>=2?e.nombre.split(' ')[0][0]+e.nombre.split(' ')[1][0]:e.nombre.substring(0,2);
    var cursosEst=_cursos.filter(function(c){ return (c.inscritos||[]).indexOf(e.email)>-1; });
    var cursosStr=cursosEst.length>0?cursosEst.map(function(c){ return c.titulo; }).join(', '):'Sin cursos asignados';
    return '<div class="est-card">'+
      '<div class="est-avatar">'+ini.toUpperCase()+'</div>'+
      '<div class="est-info"><h4>'+e.nombre+'</h4><p>'+e.email+'</p>'+
        '<p class="est-cursos"><i class="fas fa-book" style="margin-right:.3rem"></i>'+cursosStr+'</p>'+
      '</div>'+
      '<button class="btn-calif" onclick="abrirCalif(\''+e.email+'\',\''+e.nombre.replace(/'/g,'')+'\')">'+
        '<i class="fas fa-star" style="margin-right:.3rem"></i>Calificar'+
      '</button>'+
    '</div>';
  }).join('');
}

function abrirCalif(email, nombre){
  califEstEmail=email;
  document.getElementById('califNombre').textContent=nombre;
  var cursosEst=_cursos.filter(function(c){ return (c.inscritos||[]).indexOf(email)>-1; });
  document.getElementById('califCurso').innerHTML=cursosEst.length===0
    ?'<option value="">Sin cursos asignados</option>'
    :cursosEst.map(function(c){ return '<option value="'+c.id+'">'+c.titulo+'</option>'; }).join('');
  document.getElementById('califNota').value='';
  document.getElementById('califComentario').value='';
  document.getElementById('msgCalif').className='msg';
  document.getElementById('modalCalif').classList.add('open');
}

async function guardarCalif(){
  var cursoId=document.getElementById('califCurso').value;
  var nota=parseFloat(document.getElementById('califNota').value);
  var comentario=document.getElementById('califComentario').value.trim();
  if(!cursoId){ mostrarMsg('msgCalif','Selecciona un curso.','err'); return; }
  if(isNaN(nota)||nota<0||nota>20){ mostrarMsg('msgCalif','La nota debe ser entre 0 y 20.','err'); return; }
  await actualizarProfesorDB(codeSesion, {});  // ping
  // guardamos calificacion en el documento del estudiante
  var { actualizarEstudianteDB } = await import('../js/firebase.js');
  var est=_estudiantes.find(function(e){ return e.email===califEstEmail; });
  var calificaciones=est.calificaciones||{};
  calificaciones[cursoId]={ nota, comentario, fecha:new Date().toLocaleDateString() };
  await actualizarEstudianteDB(califEstEmail, { calificaciones });
  mostrarMsg('msgCalif','¡Calificación guardada!','ok');
  setTimeout(function(){ cerrarModal('modalCalif'); renderEstudiantes(); },1200);
}

/* =========================================================
   UTILS
   ========================================================= */
function showPanel(id){
  document.querySelectorAll('.panel').forEach(function(p){ p.classList.remove('active'); });
  document.querySelectorAll('.sb-link').forEach(function(b){ b.classList.remove('active'); });
  document.getElementById('panel-'+id).classList.add('active');
  var map={perfil:0,cursos:1,estudiantes:2,seguridad:3};
  document.querySelectorAll('.sb-link')[map[id]].classList.add('active');
  if(id==='cursos') cargarCursos();
  if(id==='estudiantes') cargarEstudiantes();
}
function cerrarModal(id){ document.getElementById(id).classList.remove('open'); }
function mostrarMsg(id, texto, tipo){
  var el=document.getElementById(id);
  el.textContent=texto; el.className='msg '+tipo;
  setTimeout(function(){ el.className='msg'; },3500);
}
function tp(id){ var i=document.getElementById(id); i.type=i.type==='password'?'text':'password'; }
function cerrarSesion(){ localStorage.removeItem('edutech_sesion'); window.location.href='../auth-profesor/index.html'; }

window.guardarPerfil=guardarPerfil; window.cambiarPass=cambiarPass; window.subirFoto=subirFoto;
window.crearCurso=crearCurso; window.toggleCurso=toggleCurso; window.agregarMaterial=agregarMaterial;
window.eliminarMaterial=eliminarMaterial; window.eliminarCurso=eliminarCurso; window.toggleOcultar=toggleOcultar;
window.abrirAsignar=abrirAsignar; window.guardarAsignacion=guardarAsignacion;
window.abrirCalif=abrirCalif; window.guardarCalif=guardarCalif;
window.showPanel=showPanel; window.cerrarModal=cerrarModal; window.tp=tp; window.cerrarSesion=cerrarSesion;

init();

/* ===== BOTTOM NAV MÓVIL ===== */
function switchBnm(id){
  document.querySelectorAll('.bnm-item').forEach(function(b){ b.classList.remove('active'); });
  var btn=document.getElementById('bnm-'+id);
  if(btn) btn.classList.add('active');
}
if(window.innerWidth<=480){
  var bnm=document.getElementById('bottomNavProf');
  if(bnm) bnm.style.display='flex';
}
window.switchBnm=switchBnm;
