/* =========================================================
   AUTH ESTUDIANTE — Firestore
   ========================================================= */
import {
  registrarEstudianteDB, loginEstudianteDB, getEstudianteDB,
  guardarTempPassEstDB, verificarTempPassEstDB, guardarNuevaPassEstDB
} from '../js/firebase.js';

var EJ_PUBLIC_KEY   = 'F9YR2V3CNSbnu5Eo2';
var EJ_SERVICE_ID   = 'service_edutech';
var EJ_TEMPLATE_EST = 'template_hy48vwi';
emailjs.init({ publicKey: EJ_PUBLIC_KEY });

function emailValido(e){ return e.endsWith('@gmail.com') || e.endsWith('@outlook.com'); }

function mostrarMsg(id, texto, tipo){
  var el=document.getElementById(id); if(!el) return;
  el.textContent=texto; el.style.display='block';
  el.style.background = tipo==='ok'?'#dcfce7':'#fee2e2';
  el.style.color      = tipo==='ok'?'#166534':'#991b1b';
  el.style.border     = '1.5px solid '+(tipo==='ok'?'#86efac':'#fca5a5');
}
function ocultarMsg(id){ var el=document.getElementById(id); if(el) el.style.display='none'; }
function togglePass(id){ var i=document.getElementById(id); i.type=i.type==='password'?'text':'password'; }

function generarTempPass(){
  var c='ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789',p='';
  for(var i=0;i<10;i++) p+=c[Math.floor(Math.random()*c.length)];
  return p;
}

/* ── REGISTRO ── */
async function registrarEstudiante(){
  var nombre = document.getElementById('regNombre').value.trim();
  var email  = document.getElementById('regEmail').value.trim().toLowerCase();
  var pass   = document.getElementById('passRegister').value;

  if(!nombre||!email||!pass){ mostrarMsg('regMsg','Por favor completa todos los campos.','err'); return; }
  if(!emailValido(email)){ mostrarMsg('regMsg','Solo se permiten correos @gmail.com o @outlook.com','err'); return; }
  if(pass.length<8){ mostrarMsg('regMsg','La contraseña debe tener mínimo 8 caracteres.','err'); return; }

  var btn=document.getElementById('btnRegistrar');
  btn.disabled=true; btn.innerHTML='<i class="fas fa-circle-notch spin" style="margin-right:0.5rem"></i>Creando cuenta...';

  try {
    await registrarEstudianteDB(nombre, email, pass);
    emailjs.send(EJ_SERVICE_ID, EJ_TEMPLATE_EST, { to_name:nombre, to_email:email, tipo:'bienvenida' })
      .catch(function(e){ console.warn('EmailJS:',e); });
    btn.disabled=false; btn.innerHTML='Registrate';
    mostrarMsg('regMsg','¡Cuenta creada! Te enviamos un correo de bienvenida. Ahora inicia sesión.','ok');
    document.getElementById('regNombre').value='';
    document.getElementById('regEmail').value='';
    document.getElementById('passRegister').value='';
    setTimeout(function(){ switchTab('login'); }, 2500);
  } catch(err){
    btn.disabled=false; btn.innerHTML='Registrate';
    mostrarMsg('regMsg', err.message || 'Error al registrar.', 'err');
  }
}

/* ── LOGIN ── */
var loginIntentos=0, MAX_INTENTOS=3;

function actualizarPips(){
  for(var i=1;i<=3;i++){
    var pip=document.getElementById('pip'+i); if(!pip) continue;
    pip.className='attempt-pip';
    if(i<=MAX_INTENTOS-loginIntentos) pip.classList.add('ok');
    else pip.classList.add('fail');
  }
  var r=MAX_INTENTOS-loginIntentos;
  var txt=document.getElementById('attemptsTxt');
  if(txt) txt.textContent=r>0?r+' intento'+(r===1?'':'s')+' restante'+(r===1?'':'s'):'Sin intentos';
}

function mostrarBloqueadoONormal(){
  if(loginIntentos>=MAX_INTENTOS){
    document.getElementById('loginNormal').classList.add('hidden');
    document.getElementById('loginBloqueado').classList.remove('hidden');
  } else {
    document.getElementById('loginNormal').classList.remove('hidden');
    document.getElementById('loginBloqueado').classList.add('hidden');
  }
}

async function loginEstudiante(){
  ocultarMsg('loginMsg');
  var email=document.getElementById('loginEmail').value.trim().toLowerCase();
  var pass=document.getElementById('passLogin').value;
  if(!email||!pass){ mostrarMsg('loginMsg','Por favor completa todos los campos.','err'); return; }
  if(!emailValido(email)){ mostrarMsg('loginMsg','Solo se permiten correos @gmail.com o @outlook.com','err'); return; }

  try {
    var usuario = await loginEstudianteDB(email, pass);
    localStorage.setItem('edutech_sesion', JSON.stringify(usuario));
    mostrarMsg('loginMsg','¡Bienvenido, '+usuario.nombre.split(' ')[0]+'! Redirigiendo...','ok');
    setTimeout(function(){ window.location.href='../perfil-estudiante/index.html'; }, 1500);
  } catch(err){
    loginIntentos++;
    actualizarPips();
    if(loginIntentos>=MAX_INTENTOS){ mostrarBloqueadoONormal(); }
    else {
      var r=MAX_INTENTOS-loginIntentos;
      mostrarMsg('loginMsg','Correo o contraseña incorrectos. '+r+' intento'+(r===1?'':'s')+' restante'+(r===1?'':'s')+'.','err');
    }
  }
}

/* ── RECUPERACIÓN ── */
var recEmailGuardado='';

function irRecuperacion(){
  document.getElementById('formLogin').classList.add('hidden');
  document.getElementById('formRecovery').classList.remove('hidden');
  document.getElementById('titleLogin').querySelector('h1').textContent='Recuperar contraseña';
  document.getElementById('titleLogin').querySelector('p').textContent='Te enviaremos una contraseña temporal';
  irRecStep(1);
}
function volverLogin(){
  document.getElementById('formRecovery').classList.add('hidden');
  document.getElementById('formLogin').classList.remove('hidden');
  document.getElementById('titleLogin').querySelector('h1').textContent='Iniciar Sesión';
  document.getElementById('titleLogin').querySelector('p').textContent='Ingresa tus datos para continuar';
}
function irRecStep(n){
  document.querySelectorAll('.rec-step').forEach(function(s){ s.classList.remove('active'); });
  var el=document.getElementById('recStep'+n); if(el) el.classList.add('active');
}

async function enviarTempEst(){
  ocultarMsg('recMsg1');
  var email=document.getElementById('recEmail').value.trim().toLowerCase();
  if(!email){ mostrarMsg('recMsg1','Ingresa tu correo.','err'); return; }
  if(!emailValido(email)){ mostrarMsg('recMsg1','Correo inválido.','err'); return; }

  var temp=generarTempPass();
  try {
    await guardarTempPassEstDB(email, temp);
    recEmailGuardado=email;
    emailjs.send(EJ_SERVICE_ID, EJ_TEMPLATE_EST, { to_email:email, temp_pass:temp, tipo:'recuperacion' })
      .catch(function(e){ console.warn('EmailJS:',e); });
    mostrarMsg('recMsg1','¡Correo enviado! Revisa tu bandeja.','ok');
    setTimeout(function(){ irRecStep(2); }, 1500);
  } catch(err){
    mostrarMsg('recMsg1', err.message||'Error al buscar la cuenta.','err');
  }
}

async function verificarTempEst(){
  ocultarMsg('recMsg2');
  var entered=document.getElementById('recTempPass').value;
  if(!entered){ mostrarMsg('recMsg2','Ingresa la contraseña temporal.','err'); return; }
  try {
    await verificarTempPassEstDB(recEmailGuardado, entered);
    mostrarMsg('recMsg2','¡Verificado! Crea tu nueva contraseña.','ok');
    setTimeout(function(){ irRecStep(3); }, 1200);
  } catch(err){
    mostrarMsg('recMsg2', err.message,'err');
  }
}

async function guardarNuevaPassEst(){
  ocultarMsg('recMsg3');
  var p1=document.getElementById('recNewPass1').value;
  var p2=document.getElementById('recNewPass2').value;
  if(p1.length<8){ mostrarMsg('recMsg3','Mínimo 8 caracteres.','err'); return; }
  if(p1!==p2){ mostrarMsg('recMsg3','Las contraseñas no coinciden.','err'); return; }
  try {
    await guardarNuevaPassEstDB(recEmailGuardado, p1);
    loginIntentos=0; actualizarPips(); mostrarBloqueadoONormal();
    mostrarMsg('recMsg3','¡Contraseña actualizada! Volviendo al login...','ok');
    setTimeout(function(){ volverLogin(); }, 1800);
  } catch(err){
    mostrarMsg('recMsg3', err.message,'err');
  }
}

function switchTab(tab){
  var fl=document.getElementById('formLogin'),fr=document.getElementById('formRegister');
  var fRec=document.getElementById('formRecovery');
  var tl=document.getElementById('titleLogin'),tr=document.getElementById('titleRegister');
  var bl=document.getElementById('btnLogin'),br=document.getElementById('btnRegister');
  ocultarMsg('loginMsg'); ocultarMsg('regMsg');
  fRec.classList.add('hidden');
  tl.querySelector('h1').textContent='Iniciar Sesión';
  tl.querySelector('p').textContent='Ingresa tus datos para continuar';
  if(tab==='login'){
    fl.classList.remove('hidden'); fr.classList.add('hidden');
    tl.classList.remove('hidden'); tr.classList.add('hidden');
    bl.classList.add('active');    br.classList.remove('active');
    mostrarBloqueadoONormal();
  } else {
    fl.classList.add('hidden');    fr.classList.remove('hidden');
    tl.classList.add('hidden');    tr.classList.remove('hidden');
    bl.classList.remove('active'); br.classList.add('active');
  }
}

actualizarPips();

window.registrarEstudiante=registrarEstudiante;
window.loginEstudiante=loginEstudiante;
window.enviarTempEst=enviarTempEst;
window.verificarTempEst=verificarTempEst;
window.guardarNuevaPassEst=guardarNuevaPassEst;
window.switchTab=switchTab;
window.volverLogin=volverLogin;
window.irRecuperacion=irRecuperacion;
window.togglePass=togglePass;
