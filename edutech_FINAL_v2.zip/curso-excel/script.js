/* ── Módulos acordeón ── */
function toggleModulo(header){
  var modulo = header.parentElement;
  modulo.classList.toggle('open');
}

/* ── Inscripción (Firestore real, unificada con el panel de perfil) ── */
import { inscribirseDB, estaInscritooDB } from '../js/firebase.js';

var CURSO_ID = 'excel';
var btnInscribir = null;

async function actualizarEstadoBoton(){
  var sesion = localStorage.getItem('edutech_sesion');
  if(!sesion) return;
  var usuario = JSON.parse(sesion);
  var yaInscrito = await estaInscritooDB(CURSO_ID, usuario.email);
  if(yaInscrito && btnInscribir){
    btnInscribir.innerHTML = '<i class="fas fa-check-circle"></i> Ya estás inscrito';
    btnInscribir.classList.add('inscrito');
    btnInscribir.disabled = true;
  }
}

async function inscribirse(){
  var sesion = localStorage.getItem('edutech_sesion');
  if(!sesion){
    mostrarToast('Debes iniciar sesión primero');
    setTimeout(function(){ window.location.href='../auth/index.html'; }, 1800);
    return;
  }
  var usuario = JSON.parse(sesion);
  var yaInscrito = await estaInscritooDB(CURSO_ID, usuario.email);
  if(yaInscrito){
    mostrarToast('¡Ya estás inscrito en este curso!');
    return;
  }
  await inscribirseDB(CURSO_ID, usuario.email);
  mostrarToast('¡Te has inscrito al curso de Excel!');
  await actualizarEstadoBoton();
}

function mostrarToast(msg){
  var t = document.getElementById('toast');
  document.getElementById('toastMsg').textContent = msg;
  t.classList.add('show');
  setTimeout(function(){ t.classList.remove('show'); }, 3000);
}

document.addEventListener('DOMContentLoaded', function(){
  btnInscribir = document.querySelector('.btn-inscribir');
  actualizarEstadoBoton();
});

window.toggleModulo = toggleModulo;
window.inscribirse = inscribirse;
