/* =========================================================
   PERFIL ESTUDIANTE — Firestore
   ========================================================= */
import {
  getEstudianteDB, actualizarEstudianteDB,
  getTodosCursosDB,
  getCursosInscritosDB, inscribirseDB, desinscribirseDB, estaInscritooDB,
  getEntregasEstudianteDB, enviarEntregaDB
} from '../js/firebase.js';

var sesion=JSON.parse(localStorage.getItem('edutech_sesion')||'null');
if(!sesion||sesion.rol!=='estudiante') window.location.href='../auth/index.html';

var _est=null;
var _todosCursos=[];
var _cursosInscritos=[];

/* Cursos oficiales de EduTech (páginas estáticas), mostrados siempre en el catálogo */
var CURSOS_DEFECTO=[
  {id:'word',        titulo:'Word',        categoria:'Ofimática',     nivel:'Principiante', img:'../imagenes/WORD.jpg',       link:'../curso-word/index.html',       desc:'Crea documentos, cartas y trabajos escolares de forma profesional.'},
  {id:'powerpoint',  titulo:'PowerPoint',  categoria:'Ofimática',     nivel:'Intermedio',   img:'../imagenes/PPT.jpg',        link:'../curso-powerpoint/index.html', desc:'Diseña presentaciones atractivas y dinámicas para tus exposiciones.'},
  {id:'excel',       titulo:'Excel',       categoria:'Ofimática',     nivel:'Avanzado',     img:'../imagenes/EXCEL.jpg',      link:'../curso-excel/index.html',      desc:'Organiza datos, crea tablas y realiza cálculos con hojas de cálculo.'},
  {id:'scratch',     titulo:'Scratch',     categoria:'Programación',  nivel:'Principiante', img:'../imagenes/SCRATH.jpg',     link:'../curso-scratch/index.html',    desc:'Programación visual por bloques: crea juegos e historias interactivas.'},
  {id:'mbot',        titulo:'mBOT',        categoria:'Programación',  nivel:'Intermedio',   img:'../imagenes/MBOT.jpg',       link:'../curso-mbot/index.html',       desc:'Aprende robótica y programación con el robot educativo mBot.'},
  {id:'photoshop',   titulo:'Photoshop',   categoria:'Diseño Gráfico',nivel:'Principiante', img:'../imagenes/PSD.jpg',        link:'../curso-photoshop/index.html',  desc:'Edición y retoque de imágenes y creación de arte digital.'},
  {id:'coreldraw',   titulo:'CorelDRAW',   categoria:'Diseño Gráfico',nivel:'Intermedio',   img:'../imagenes/CORELDRAW.jpg',  link:'../curso-coreldraw/index.html',  desc:'Diseña logos, ilustraciones y vectores profesionales.'}
];

function getUrlDescarga(url){
  if(!url) return url;
  var m=url.match(/drive\.google\.com\/file\/d\/([^/]+)/);
  if(m) return 'https://drive.google.com/uc?export=download&id='+m[1];
  return url;
}

/* =========================================================
   INIT
   ========================================================= */
async function init(){
  _est=await getEstudianteDB(sesion.email);
  if(!_est){ cerrarSesion(); return; }

  document.getElementById('topNombre').textContent=_est.nombre.split(' ')[0];
  document.getElementById('perfilNombre').textContent=_est.nombre;
  document.getElementById('perfilEmail').textContent=_est.email;
  document.getElementById('editNombre').value=_est.nombre;
  document.getElementById('editEmail').value=_est.email;

  var partes=_est.nombre.split(' ');
  var ini=partes.length>=2?partes[0][0]+partes[1][0]:partes[0].substring(0,2);
  document.getElementById('avatarInitials').textContent=ini.toUpperCase();
  if(_est.foto) mostrarFoto(_est.foto);

  _cursosInscritos=await getCursosInscritosDB(sesion.email);
  _todosCursos=await getTodosCursosDB();

  renderCatalogo();
  renderMisCursos();
  await renderEntregas();
}

/* =========================================================
   FOTO Y PERFIL
   ========================================================= */
function mostrarFoto(src){
  var img=document.getElementById('avatarImg');
  img.src=src; img.style.display='block';
  document.getElementById('avatarInitials').style.display='none';
}
function subirFoto(input){
  var file=input.files[0]; if(!file) return;
  var reader=new FileReader();
  reader.onload=async function(e){
    mostrarFoto(e.target.result);
    await actualizarEstudianteDB(sesion.email,{foto:e.target.result});
  };
  reader.readAsDataURL(file);
}
async function guardarPerfil(){
  var nombre=document.getElementById('editNombre').value.trim();
  if(!nombre){ mostrarMsg('msgPerfil','El nombre no puede estar vacío.','err'); return; }
  await actualizarEstudianteDB(sesion.email,{nombre});
  sesion.nombre=nombre;
  localStorage.setItem('edutech_sesion',JSON.stringify(sesion));
  document.getElementById('perfilNombre').textContent=nombre;
  document.getElementById('topNombre').textContent=nombre.split(' ')[0];
  mostrarMsg('msgPerfil','¡Datos actualizados!','ok');
}
async function cambiarPass(){
  var actual=document.getElementById('passActual').value;
  var p1=document.getElementById('passNueva1').value;
  var p2=document.getElementById('passNueva2').value;
  if(_est.pass!==actual){ mostrarMsg('msgPass','Contraseña actual incorrecta.','err'); return; }
  if(p1.length<8){ mostrarMsg('msgPass','Mínimo 8 caracteres.','err'); return; }
  if(p1!==p2){ mostrarMsg('msgPass','Las contraseñas no coinciden.','err'); return; }
  await actualizarEstudianteDB(sesion.email,{pass:p1});
  _est.pass=p1;
  document.getElementById('passActual').value='';
  document.getElementById('passNueva1').value='';
  document.getElementById('passNueva2').value='';
  mostrarMsg('msgPass','¡Contraseña actualizada!','ok');
}

/* =========================================================
   CATÁLOGO
   ========================================================= */
function renderCatalogo(){
  var el=document.getElementById('catalogoGrid');
  var visibles=_todosCursos.filter(function(c){ return !c.oculto; });

  var htmlDefecto = '<div class="cat-section-title">Cursos oficiales de EduTech</div>' +
    '<div class="cursos-grid-img">' +
    CURSOS_DEFECTO.map(function(c){
      var inscrito=_cursosInscritos.indexOf(c.id)>-1;
      var nivelClase = c.nivel==='Principiante' ? 'niv-principiante' : c.nivel==='Intermedio' ? 'niv-intermedio' : 'niv-avanzado';
      return '<div class="curso-img-card">'+
        '<div class="cic-img"><img src="'+c.img+'" alt="'+c.titulo+'" loading="lazy"/>'+
          '<span class="cic-nivel '+nivelClase+'">'+c.nivel+'</span>'+
        '</div>'+
        '<div class="cic-body">'+
          '<span class="cic-cat">'+c.categoria+'</span>'+
          '<h4>'+c.titulo+'</h4>'+
          '<p>'+c.desc+'</p>'+
          '<div class="cic-actions">'+
            '<a href="'+c.link+'" class="btn-ver-curso"><i class="fas fa-eye"></i> Ver curso</a>'+
            '<button class="btn-inscribir-mini'+(inscrito?' inscrito':'')+'" onclick="toggleInscripcionDefecto(\''+c.id+'\', this)">'+
              (inscrito?'<i class="fas fa-check"></i> Inscrito':'<i class="fas fa-plus"></i> Inscribirme')+
            '</button>'+
          '</div>'+
        '</div>'+
      '</div>';
    }).join('') +
    '</div>';

  var htmlProfesores = '';
  if(visibles.length>0){
    htmlProfesores = '<div class="cat-section-title cat-section-title-2">Cursos creados por profesores</div>' +
      visibles.map(function(c){
        var inscrito=_cursosInscritos.indexOf(c.id)>-1;
        var materiales=(c.materiales||[]).map(function(m){
          var ico=m.tipo==='pdf'?'fa-file-pdf':m.tipo==='video'?'fa-play-circle':'fa-link';
          return '<div class="material-item"><i class="fas '+ico+'"></i>'+m.nombre+
            '<div class="material-acciones">'+
              '<a href="'+m.url+'" target="_blank"><i class="fas fa-eye"></i> Ver</a>'+
              '<a href="'+getUrlDescarga(m.url)+'" download="'+m.nombre+'" target="_blank"><i class="fas fa-download"></i> Descargar</a>'+
            '</div></div>';
        }).join('');
        return '<div class="mi-curso-card">'+
          '<div class="mi-curso-header" onclick="toggleCursoCard(\'cat-'+c.id+'\')">'+
            '<div class="mi-curso-ico">📚</div>'+
            '<div class="mi-curso-info"><h4>'+c.titulo+'</h4><p>'+c.categoria+' · Prof. '+c.profesor+'</p></div>'+
            '<button class="btn-inscribir'+(inscrito?' btn-desinscribir':'')+'" onclick="event.stopPropagation();toggleInscripcion(\''+c.id+'\')">'+
              (inscrito?'<i class="fas fa-minus-circle"></i> Desinscribirme':'<i class="fas fa-plus-circle"></i> Inscribirme')+
            '</button>'+
          '</div>'+
          '<div class="curso-body-exp" id="cat-'+c.id+'">'+
            '<p style="font-size:.85rem;color:#6b7280;margin-bottom:1rem">'+c.descripcion+'</p>'+
            (materiales||'<p style="font-size:.82rem;color:#9ca3af">Sin materiales aún.</p>')+
          '</div>'+
        '</div>';
      }).join('');
  }

  el.innerHTML = htmlDefecto + htmlProfesores;
}

async function toggleInscripcionDefecto(cursoId, btn){
  var inscrito=_cursosInscritos.indexOf(cursoId)>-1;
  if(inscrito){
    await desinscribirseDB(cursoId, sesion.email);
    _cursosInscritos=_cursosInscritos.filter(function(id){ return id!==cursoId; });
    btn.classList.remove('inscrito');
    btn.innerHTML='<i class="fas fa-plus"></i> Inscribirme';
  } else {
    await inscribirseDB(cursoId, sesion.email);
    _cursosInscritos.push(cursoId);
    btn.classList.add('inscrito');
    btn.innerHTML='<i class="fas fa-check"></i> Inscrito';
  }
  renderMisCursos();
}


async function toggleInscripcion(cursoId){
  var inscrito=_cursosInscritos.indexOf(cursoId)>-1;
  if(inscrito){
    await desinscribirseDB(cursoId, sesion.email);
    _cursosInscritos=_cursosInscritos.filter(function(id){ return id!==cursoId; });
  } else {
    await inscribirseDB(cursoId, sesion.email);
    _cursosInscritos.push(cursoId);
  }
  renderCatalogo();
  renderMisCursos();
}

/* =========================================================
   MIS CURSOS
   ========================================================= */
function renderMisCursos(){
  var el=document.getElementById('misCursosLista');
  var misCursosProf=_todosCursos.filter(function(c){ return _cursosInscritos.indexOf(c.id)>-1; });
  var misCursosDefecto=CURSOS_DEFECTO.filter(function(c){ return _cursosInscritos.indexOf(c.id)>-1; });

  if(misCursosProf.length===0 && misCursosDefecto.length===0){
    el.innerHTML='<div class="empty-state"><div class="empty-ico">🎒</div><p>Aún no estás inscrito en ningún curso.</p></div>';
    return;
  }

  var htmlDefecto = misCursosDefecto.length===0 ? '' : '<div class="cursos-grid-img">' +
    misCursosDefecto.map(function(c){
      return '<div class="curso-img-card">'+
        '<div class="cic-img"><img src="'+c.img+'" alt="'+c.titulo+'" loading="lazy"/></div>'+
        '<div class="cic-body">'+
          '<span class="cic-cat">'+c.categoria+'</span>'+
          '<h4>'+c.titulo+'</h4>'+
          '<p>'+c.desc+'</p>'+
          '<div class="cic-actions"><a href="'+c.link+'" class="btn-ver-curso"><i class="fas fa-play"></i> Continuar curso</a></div>'+
        '</div>'+
      '</div>';
    }).join('') + '</div>';

  var misCursos = misCursosProf;
  el.innerHTML = htmlDefecto + misCursos.map(function(c){
    var materiales=(c.materiales||[]).map(function(m){
      var ico=m.tipo==='pdf'?'fa-file-pdf':m.tipo==='video'?'fa-play-circle':'fa-link';
      return '<div class="material-item"><i class="fas '+ico+'"></i>'+m.nombre+
        '<div class="material-acciones">'+
          '<a href="'+m.url+'" target="_blank"><i class="fas fa-eye"></i> Ver</a>'+
          '<a href="'+getUrlDescarga(m.url)+'" download="'+m.nombre+'" target="_blank"><i class="fas fa-download"></i> Descargar</a>'+
        '</div></div>';
    }).join('');
    return '<div class="mi-curso-card">'+
      '<div class="mi-curso-header" onclick="toggleCursoCard(\'mis-'+c.id+'\')">'+
        '<div class="mi-curso-ico">🎓</div>'+
        '<div class="mi-curso-info"><h4>'+c.titulo+'</h4><p>'+c.categoria+' · Prof. '+c.profesor+'</p></div>'+
      '</div>'+
      '<div class="curso-body-exp" id="mis-'+c.id+'">'+
        '<p style="font-size:.85rem;color:#6b7280;margin-bottom:1rem">'+c.descripcion+'</p>'+
        '<div class="material-list">'+(materiales||'<p style="font-size:.82rem;color:#9ca3af">Sin materiales aún.</p>')+'</div>'+
      '</div>'+
    '</div>';
  }).join('');
}

function toggleCursoCard(id){
  document.getElementById(id).classList.toggle('open');
}

/* =========================================================
   ENTREGAS
   ========================================================= */
async function renderEntregas(){
  var el=document.getElementById('entregasLista'); if(!el) return;
  var entregas=await getEntregasEstudianteDB(sesion.email);
  var sel=document.getElementById('entregaCurso');
  if(sel){
    var misCursos=_todosCursos.filter(function(c){ return _cursosInscritos.indexOf(c.id)>-1; });
    sel.innerHTML='<option value="">Selecciona un curso</option>'+
      misCursos.map(function(c){ return '<option value="'+c.id+'">'+c.titulo+'</option>'; }).join('');
  }
  if(entregas.length===0){
    el.innerHTML='<div class="empty-state"><div class="empty-ico">📋</div><p>Aún no has enviado entregas.</p></div>';
    return;
  }
  el.innerHTML=entregas.map(function(e){
    var curso=_todosCursos.find(function(c){ return c.id===e.cursoId; });
    return '<div class="est-card">'+
      '<div class="est-avatar">📄</div>'+
      '<div class="est-info">'+
        '<h4>'+(curso?curso.titulo:'Curso eliminado')+'</h4>'+
        '<p>'+e.descripcion+'</p>'+
        (e.archivoUrl?'<a href="'+e.archivoUrl+'" target="_blank" style="font-size:.8rem;color:#3a86ff"><i class="fas fa-paperclip"></i> '+e.nombreArchivo+'</a>':'')+
      '</div>'+
    '</div>';
  }).join('');
}

async function enviarEntrega(){
  var cursoId=document.getElementById('entregaCurso').value;
  var desc=document.getElementById('entregaDesc').value.trim();
  if(!cursoId||!desc){ mostrarMsg('msgEntrega','Selecciona un curso y agrega una descripción.','err'); return; }
  await enviarEntregaDB(cursoId, sesion.email, desc, '', '');
  document.getElementById('entregaDesc').value='';
  mostrarMsg('msgEntrega','¡Entrega enviada!','ok');
  await renderEntregas();
}

/* =========================================================
   UTILS
   ========================================================= */
function showPanel(id){
  document.querySelectorAll('.panel').forEach(function(p){ p.classList.remove('active'); });
  document.querySelectorAll('.sb-link').forEach(function(b){ b.classList.remove('active'); });
  document.getElementById('panel-'+id).classList.add('active');
  var map={perfil:0,catalogo:1,miscursos:2,seguridad:3};
  if(map[id]!==undefined && document.querySelectorAll('.sb-link')[map[id]]) document.querySelectorAll('.sb-link')[map[id]].classList.add('active');
  if(id==='catalogo'){ _todosCursos.length===0?init():renderCatalogo(); }
  if(id==='miscursos') renderMisCursos();

}
function mostrarMsg(id, texto, tipo){
  var el=document.getElementById(id); if(!el) return;
  el.textContent=texto; el.className='msg '+tipo;
  setTimeout(function(){ el.className='msg'; },3500);
}
function tp(id){ var i=document.getElementById(id); i.type=i.type==='password'?'text':'password'; }
function cerrarSesion(){ localStorage.removeItem('edutech_sesion'); window.location.href='../auth/index.html'; }

window.guardarPerfil=guardarPerfil; window.cambiarPass=cambiarPass; window.subirFoto=subirFoto;
window.toggleInscripcion=toggleInscripcion; window.toggleCursoCard=toggleCursoCard;
window.toggleInscripcionDefecto=toggleInscripcionDefecto;
window.enviarEntrega=enviarEntrega;
window.showPanel=showPanel; window.tp=tp; window.cerrarSesion=cerrarSesion;

init();

/* ===== BOTTOM NAV MÓVIL ===== */
function switchBnm(id){
  document.querySelectorAll('.bnm-item').forEach(function(b){ b.classList.remove('active'); });
  var btn=document.getElementById('bnm-'+id);
  if(btn) btn.classList.add('active');
}
if(window.innerWidth<=480){
  var bnm=document.getElementById('bottomNavEst');
  if(bnm) bnm.style.display='flex';
}
window.switchBnm=switchBnm;
