/* =========================================================
   AUTH PROFESOR — Firestore
   ========================================================= */
import {
  registrarProfesorDB, loginProfesorDB,
  emailProfesorExisteDB, codigoProfesorLibreDB,
  guardarTempPassProfDB, verificarTempPassProfDB, guardarNuevaPassProfDB
} from '../js/firebase.js';

var EJ_PUBLIC_KEY  = 'F9YR2V3CNSbnu5Eo2';
var EJ_SERVICE_ID  = 'service_edutech';
var EJ_TEMPLATE_ID = 'template_kn6mf13';
emailjs.init({ publicKey: EJ_PUBLIC_KEY });

function emailValido(e){ return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }
function togglePass(id){ var i=document.getElementById(id); i.type=i.type==='password'?'text':'password'; }

function mostrarMsg(id, texto, tipo){
  var el=document.getElementById(id); if(!el) return;
  el.textContent=texto; el.style.display='block';
  el.style.background=tipo==='ok'?'#fefce8':'#fee2e2';
  el.style.color=tipo==='ok'?'#713f12':'#991b1b';
  el.style.border='1.5px solid '+(tipo==='ok'?'#f4d35e':'#fca5a5');
}
function ocultarMsg(id){ var el=document.getElementById(id); if(el) el.style.display='none'; }

async function generarCodigoLibre(){
  var code;
  do {
    code=String(Math.floor(100000+Math.random()*900000));
  } while(!(await codigoProfesorLibreDB(code)));
  return code;
}

function generarTempPass(){
  var c='ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789',p='';
  for(var i=0;i<10;i++) p+=c[Math.floor(Math.random()*c.length)];
  return p;
}

/* ── LOGIN ── */
var loginIntentos=0, MAX_INTENTOS=3;

function actualizarPips(){
  for(var i=1;i<=3;i++){
    var pip=document.getElementById('pip'+i); if(!pip) continue;
    pip.className='attempt-pip';
    if(i<=MAX_INTENTOS-loginIntentos) pip.classList.add('ok');
    else pip.classList.add('fail');
  }
  var r=MAX_INTENTOS-loginIntentos;
  var txt=document.getElementById('attemptsTxt');
  if(txt) txt.textContent=r>0?r+' intento'+(r===1?'':'s')+' restante'+(r===1?'':'s'):'Sin intentos';
}

function mostrarBloqueadoONormal(){
  if(loginIntentos>=MAX_INTENTOS){
    document.getElementById('loginNormal').classList.add('hidden');
    document.getElementById('loginBloqueado').classList.remove('hidden');
  } else {
    document.getElementById('loginNormal').classList.remove('hidden');
    document.getElementById('loginBloqueado').classList.add('hidden');
  }
}

async function loginProfesor(){
  ocultarMsg('loginMsg');
  var code=document.getElementById('loginCode').value.trim();
  var pass=document.getElementById('loginPass').value;
  if(!code||!pass){ mostrarMsg('loginMsg','Completa todos los campos.','err'); return; }
  try {
    var prof=await loginProfesorDB(code, pass);
    localStorage.setItem('edutech_sesion', JSON.stringify(prof));
    mostrarMsg('loginMsg','¡Bienvenido, '+prof.nombre.split(' ')[0]+'! Redirigiendo...','ok');
    setTimeout(function(){ window.location.href='../perfil-profesor/index.html'; }, 1500);
  } catch(err){
    loginIntentos++;
    actualizarPips();
    if(loginIntentos>=MAX_INTENTOS){ mostrarBloqueadoONormal(); }
    else {
      var r=MAX_INTENTOS-loginIntentos;
      mostrarMsg('loginMsg','Código o contraseña incorrectos. '+r+' intento'+(r===1?'':'s')+' restante'+(r===1?'':'s')+'.','err');
    }
  }
}

/* ── REGISTRO ── */
var regDataTemp={};

function irRegStep(n){
  document.querySelectorAll('.step').forEach(function(s){ s.classList.remove('active'); });
  var el=document.getElementById('regStep'+n); if(el) el.classList.add('active');
  for(var i=1;i<=3;i++){
    var dot=document.getElementById('sdot'+i); if(!dot) continue;
    dot.className='sdot';
    if(i<n) dot.classList.add('done');
    else if(i===n) dot.classList.add('active');
  }
  ocultarMsg('regMsg');
}

async function regPaso1(){
  ocultarMsg('regMsg');
  var nombre=document.getElementById('regNombre').value.trim();
  var email=document.getElementById('regEmail').value.trim().toLowerCase();
  if(!nombre||!email){ mostrarMsg('regMsg','Nombre y correo son obligatorios.','err'); return; }
  if(!emailValido(email)){ mostrarMsg('regMsg','Correo inválido.','err'); return; }
  try {
    var existe=await emailProfesorExisteDB(email);
    if(existe){ mostrarMsg('regMsg','Este correo ya tiene una cuenta de profesor.','err'); return; }
    regDataTemp.nombre=nombre; regDataTemp.email=email;
    irRegStep(2);
  } catch(err){ mostrarMsg('regMsg','Error al verificar. Intenta de nuevo.','err'); }
}

function regPaso2(){
  ocultarMsg('regMsg');
  var p1=document.getElementById('regPass1').value;
  var p2=document.getElementById('regPass2').value;
  if(p1.length<8){ mostrarMsg('regMsg','La contraseña debe tener al menos 8 caracteres.','err'); return; }
  if(p1!==p2){ mostrarMsg('regMsg','Las contraseñas no coinciden.','err'); return; }
  regDataTemp.password=p1;
  generarCodigoLibre().then(function(code){
    regDataTemp.code=code;
    document.getElementById('codigoGenerado').textContent=code;
    irRegStep(3);
  });
}

async function confirmarRegistro(){
  var btn=document.getElementById('btnConfirmar');
  btn.disabled=true; btn.innerHTML='<i class="fas fa-circle-notch spin" style="margin-right:0.5rem"></i>Enviando...';
  ocultarMsg('regMsg');
  try {
    await registrarProfesorDB(regDataTemp.nombre, regDataTemp.email, regDataTemp.password, regDataTemp.code);
    emailjs.send(EJ_SERVICE_ID, EJ_TEMPLATE_ID, {
      to_name:regDataTemp.nombre, to_email:regDataTemp.email,
      prof_code:regDataTemp.code, tipo:'registro'
    }).catch(function(e){ console.warn('EmailJS:',e); });
    btn.disabled=false; btn.innerHTML='<i class="fas fa-check" style="margin-right:0.5rem"></i>¡Enviado!';
    mostrarMsg('regMsg','¡Registro exitoso! Tu código '+regDataTemp.code+' fue enviado a '+regDataTemp.email,'ok');
    setTimeout(function(){ switchTab('login'); }, 3000);
  } catch(err){
    btn.disabled=false; btn.innerHTML='<i class="fas fa-paper-plane" style="margin-right:0.5rem"></i>Confirmar y enviar código';
    mostrarMsg('regMsg', err.message||'Error al registrar.','err');
  }
}

/* ── RECUPERACIÓN ── */
var recData={};

function irRecuperacion(){
  document.getElementById('formLogin').classList.add('hidden');
  document.getElementById('formRecovery').classList.remove('hidden');
  document.getElementById('titleLogin').querySelector('h1').textContent='Recuperar contraseña';
  document.getElementById('titleLogin').querySelector('p').textContent='Te enviaremos una contraseña temporal';
  irRecStep(1);
}
function volverLogin(){
  document.getElementById('formRecovery').classList.add('hidden');
  document.getElementById('formLogin').classList.remove('hidden');
  document.getElementById('titleLogin').querySelector('h1').textContent='Iniciar Sesión';
  document.getElementById('titleLogin').querySelector('p').textContent='Accede a tu panel de profesor';
}
function irRecStep(n){
  document.querySelectorAll('.rec-step').forEach(function(s){ s.classList.remove('active'); });
  var el=document.getElementById('recStep'+n); if(el) el.classList.add('active');
}

async function enviarContrasenaTemp(){
  ocultarMsg('recMsg1');
  var code=document.getElementById('recCode').value.trim();
  var email=document.getElementById('recEmail').value.trim().toLowerCase();
  if(!code||!email){ mostrarMsg('recMsg1','Completa ambos campos.','err'); return; }
  if(!emailValido(email)){ mostrarMsg('recMsg1','Correo inválido.','err'); return; }
  var temp=generarTempPass();
  try {
    await guardarTempPassProfDB(code, temp);
    recData={code, tempPass:temp};
    emailjs.send(EJ_SERVICE_ID, EJ_TEMPLATE_ID, { to_email:email, temp_pass:temp, tipo:'recuperacion' })
      .catch(function(e){ console.warn('EmailJS:',e); });
    mostrarMsg('recMsg1','¡Correo enviado! Revisa tu bandeja.','ok');
    setTimeout(function(){ irRecStep(2); }, 1500);
  } catch(err){ mostrarMsg('recMsg1', err.message||'Código no encontrado.','err'); }
}

async function verificarTemp(){
  ocultarMsg('recMsg2');
  var entered=document.getElementById('recTempPass').value;
  if(!entered){ mostrarMsg('recMsg2','Ingresa la contraseña temporal.','err'); return; }
  try {
    await verificarTempPassProfDB(recData.code, entered);
    mostrarMsg('recMsg2','¡Verificado! Crea tu nueva contraseña.','ok');
    setTimeout(function(){ irRecStep(3); }, 1200);
  } catch(err){ mostrarMsg('recMsg2', err.message,'err'); }
}

async function guardarNuevaPass(){
  ocultarMsg('recMsg3');
  var p1=document.getElementById('recNewPass1').value;
  var p2=document.getElementById('recNewPass2').value;
  if(p1.length<8){ mostrarMsg('recMsg3','Mínimo 8 caracteres.','err'); return; }
  if(p1!==p2){ mostrarMsg('recMsg3','Las contraseñas no coinciden.','err'); return; }
  try {
    await guardarNuevaPassProfDB(recData.code, p1);
    loginIntentos=0; actualizarPips(); mostrarBloqueadoONormal();
    mostrarMsg('recMsg3','¡Contraseña actualizada! Volviendo al login...','ok');
    setTimeout(function(){ volverLogin(); }, 1800);
  } catch(err){ mostrarMsg('recMsg3', err.message,'err'); }
}

function switchTab(tab){
  var fl=document.getElementById('formLogin'),fr=document.getElementById('formRegister');
  var tl=document.getElementById('titleLogin'),tr=document.getElementById('titleRegister');
  var bl=document.getElementById('btnLogin'),br=document.getElementById('btnRegister');
  var fRec=document.getElementById('formRecovery');
  ocultarMsg('loginMsg'); ocultarMsg('regMsg');
  fRec.classList.add('hidden'); fl.classList.remove('hidden');
  if(tab==='login'){
    fl.classList.remove('hidden'); fr.classList.add('hidden');
    tl.classList.remove('hidden'); tr.classList.add('hidden');
    bl.classList.add('active');    br.classList.remove('active');
    mostrarBloqueadoONormal();
  } else {
    fl.classList.add('hidden');    fr.classList.remove('hidden');
    tl.classList.add('hidden');    tr.classList.remove('hidden');
    bl.classList.remove('active'); br.classList.add('active');
    irRegStep(1);
  }
}

actualizarPips();

window.loginProfesor=loginProfesor;
window.regPaso1=regPaso1;
window.regPaso2=regPaso2;
window.confirmarRegistro=confirmarRegistro;
window.switchTab=switchTab;
window.irRecuperacion=irRecuperacion;
window.volverLogin=volverLogin;
window.enviarContrasenaTemp=enviarContrasenaTemp;
window.verificarTemp=verificarTemp;
window.guardarNuevaPass=guardarNuevaPass;
window.togglePass=togglePass;
