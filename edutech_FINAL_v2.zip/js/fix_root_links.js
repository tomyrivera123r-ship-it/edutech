// Ajusta enlaces que empiezan con '/' para cualquier entorno (file:// y http://)
(function(){
  function computePrefix() {
    var path = decodeURIComponent(location.pathname || '');

    // Normaliza Windows file:// rutas como /D:/... -> quita la letra de unidad
    if (/^\/[A-Za-z]:/.test(path)) path = path.replace(/^\//, '');

    var parts = path.split('/').filter(Boolean);

    // En file://: partes son [carpetas..., archivo.html]
    // En http:// (Live Server): partes son [carpeta-proyecto..., archivo.html]
    // Queremos quitar el archivo.html del conteo (última parte)
    var depth = Math.max(parts.length - 1, 0);
    depth = Math.min(depth, 8);
    return depth === 0 ? '' : Array(depth + 1).join('../');
  }

  function fix() {
    var prefix = computePrefix();
    document.querySelectorAll('a[href^="/"]').forEach(function(a){
      var href = a.getAttribute('href');
      if (!href) return;
      var newHref = href.replace(/^\//, '');
      a.setAttribute('href', prefix + newHref);
    });
  }

  // Exponer para llamada desde index.js tras cargar partials
  window.fixRootLinks = fix;

  // También intentar al DOMContentLoaded
  document.addEventListener('DOMContentLoaded', function(){ try{ fix(); }catch(e){} });
})();
