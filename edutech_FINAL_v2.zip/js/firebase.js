/* =========================================================
   EDUTECH — Firebase / Firestore
   Archivo central: importar en todos los scripts del proyecto
   ========================================================= */

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import {
  getFirestore,
  collection, doc,
  getDoc, getDocs, setDoc, updateDoc, deleteDoc, addDoc,
  query, where, orderBy, serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey:            "AIzaSyBoFH2mItLKeGDHbyMZY0CtmyZO7-C2cs8",
  authDomain:        "edutech-fdaba.firebaseapp.com",
  projectId:         "edutech-fdaba",
  storageBucket:     "edutech-fdaba.firebasestorage.app",
  messagingSenderId: "478317161049",
  appId:             "1:478317161049:web:0aee8ee2eda70baa355f48",
  measurementId:     "G-LR040TTDF0"
};

const app = initializeApp(firebaseConfig);
const db  = getFirestore(app);

/* =========================================================
   COLECCIONES EN FIRESTORE
   - estudiantes   → usuarios con rol estudiante
   - profesores    → usuarios con rol profesor
   - cursos        → cursos creados por profesores
   - inscripciones → qué alumno está en qué curso
   - entregas      → archivos/comentarios enviados por alumnos
   ========================================================= */

/* ── ESTUDIANTES ── */
export async function registrarEstudianteDB(nombre, email, pass){
  const ref = doc(db, 'estudiantes', email);
  const snap = await getDoc(ref);
  if(snap.exists()) throw new Error('Este correo ya está registrado.');
  await setDoc(ref, {
    nombre, email, pass,
    rol: 'estudiante',
    foto: '',
    creado: serverTimestamp()
  });
}

export async function loginEstudianteDB(email, pass){
  const snap = await getDoc(doc(db, 'estudiantes', email));
  if(!snap.exists()) throw new Error('Correo no encontrado.');
  const u = snap.data();
  if(u.pass !== pass) throw new Error('Contraseña incorrecta.');
  return { nombre: u.nombre, email: u.email, rol: 'estudiante', foto: u.foto || '' };
}

export async function getEstudianteDB(email){
  const snap = await getDoc(doc(db, 'estudiantes', email));
  return snap.exists() ? snap.data() : null;
}

export async function actualizarEstudianteDB(email, datos){
  await updateDoc(doc(db, 'estudiantes', email), datos);
}

export async function getTodosEstudiantesDB(){
  const snap = await getDocs(collection(db, 'estudiantes'));
  return snap.docs.map(d => d.data());
}

/* ── CONTRASEÑA TEMPORAL ESTUDIANTE ── */
export async function guardarTempPassEstDB(email, tempPass){
  await updateDoc(doc(db, 'estudiantes', email), { tempPass });
}

export async function verificarTempPassEstDB(email, tempPass){
  const snap = await getDoc(doc(db, 'estudiantes', email));
  if(!snap.exists()) throw new Error('Correo no encontrado.');
  if(snap.data().tempPass !== tempPass) throw new Error('Contraseña temporal incorrecta.');
}

export async function guardarNuevaPassEstDB(email, newPass){
  await updateDoc(doc(db, 'estudiantes', email), { pass: newPass, tempPass: '' });
}

/* ── PROFESORES ── */
export async function registrarProfesorDB(nombre, email, pass, code){
  const ref = doc(db, 'profesores', code);
  await setDoc(ref, {
    nombre, email, password: pass, code,
    foto: '',
    creado: serverTimestamp()
  });
}

export async function emailProfesorExisteDB(email){
  const q = query(collection(db, 'profesores'), where('email', '==', email));
  const snap = await getDocs(q);
  return !snap.empty;
}

export async function loginProfesorDB(code, pass){
  const snap = await getDoc(doc(db, 'profesores', code));
  if(!snap.exists()) throw new Error('Código no encontrado.');
  const p = snap.data();
  if(p.password !== pass) throw new Error('Contraseña incorrecta.');
  return { nombre: p.nombre, email: p.email, code: p.code, rol: 'profesor', foto: p.foto || '' };
}

export async function getProfesorDB(code){
  const snap = await getDoc(doc(db, 'profesores', code));
  return snap.exists() ? snap.data() : null;
}

export async function actualizarProfesorDB(code, datos){
  await updateDoc(doc(db, 'profesores', code), datos);
}

export async function codigoProfesorLibreDB(code){
  const snap = await getDoc(doc(db, 'profesores', code));
  return !snap.exists();
}

/* ── CONTRASEÑA TEMPORAL PROFESOR ── */
export async function guardarTempPassProfDB(code, tempPass){
  await updateDoc(doc(db, 'profesores', code), { tempPass });
}

export async function verificarTempPassProfDB(code, tempPass){
  const snap = await getDoc(doc(db, 'profesores', code));
  if(!snap.exists()) throw new Error('Código no encontrado.');
  if(snap.data().tempPass !== tempPass) throw new Error('Contraseña temporal incorrecta.');
}

export async function guardarNuevaPassProfDB(code, newPass){
  await updateDoc(doc(db, 'profesores', code), { password: newPass, tempPass: '' });
}

/* ── CURSOS ── */
export async function crearCursoDB(curso){
  // curso = { id, profCode, profesor, titulo, descripcion, categoria, oculto }
  await setDoc(doc(db, 'cursos', curso.id), {
    ...curso,
    materiales: [],
    creado: serverTimestamp()
  });
}

export async function getCursosProfDB(profCode){
  const q = query(collection(db, 'cursos'), where('profCode', '==', profCode));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function getTodosCursosDB(){
  const snap = await getDocs(collection(db, 'cursos'));
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function actualizarCursoDB(cursoId, datos){
  await updateDoc(doc(db, 'cursos', cursoId), datos);
}

export async function eliminarCursoDB(cursoId){
  await deleteDoc(doc(db, 'cursos', cursoId));
}

export async function toggleOcultarCursoDB(cursoId, estadoActual){
  await updateDoc(doc(db, 'cursos', cursoId), { oculto: !estadoActual });
}

/* ── MATERIALES (dentro del curso) ── */
export async function agregarMaterialDB(cursoId, material){
  const snap = await getDoc(doc(db, 'cursos', cursoId));
  if(!snap.exists()) return;
  const materiales = snap.data().materiales || [];
  materiales.push(material);
  await updateDoc(doc(db, 'cursos', cursoId), { materiales });
}

export async function eliminarMaterialDB(cursoId, materialIdx){
  const snap = await getDoc(doc(db, 'cursos', cursoId));
  if(!snap.exists()) return;
  const materiales = snap.data().materiales || [];
  materiales.splice(materialIdx, 1);
  await updateDoc(doc(db, 'cursos', cursoId), { materiales });
}

/* ── INSCRIPCIONES ── */
export async function inscribirseDB(cursoId, emailEstudiante){
  const id = cursoId + '_' + emailEstudiante.replace(/[@.]/g,'_');
  await setDoc(doc(db, 'inscripciones', id), {
    cursoId, emailEstudiante,
    fecha: serverTimestamp()
  });
}

export async function desinscribirseDB(cursoId, emailEstudiante){
  const id = cursoId + '_' + emailEstudiante.replace(/[@.]/g,'_');
  await deleteDoc(doc(db, 'inscripciones', id));
}

export async function getCursosInscritosDB(emailEstudiante){
  const q = query(collection(db, 'inscripciones'), where('emailEstudiante','==', emailEstudiante));
  const snap = await getDocs(q);
  return snap.docs.map(d => d.data().cursoId);
}

export async function getInscriptosDeCursooDB(cursoId){
  const q = query(collection(db, 'inscripciones'), where('cursoId','==', cursoId));
  const snap = await getDocs(q);
  return snap.docs.map(d => d.data().emailEstudiante);
}

export async function estaInscritooDB(cursoId, emailEstudiante){
  const id = cursoId + '_' + emailEstudiante.replace(/[@.]/g,'_');
  const snap = await getDoc(doc(db, 'inscripciones', id));
  return snap.exists();
}

/* ── ENTREGAS ── */
export async function enviarEntregaDB(cursoId, emailEstudiante, descripcion, archivoUrl, nombreArchivo){
  await addDoc(collection(db, 'entregas'), {
    cursoId, emailEstudiante, descripcion,
    archivoUrl: archivoUrl || '',
    nombreArchivo: nombreArchivo || '',
    fecha: serverTimestamp()
  });
}

export async function getEntregasEstudianteDB(emailEstudiante){
  const q = query(collection(db, 'entregas'), where('emailEstudiante','==', emailEstudiante));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export async function getEntregasCursoDB(cursoId){
  const q = query(collection(db, 'entregas'), where('cursoId','==', cursoId));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}

export { db };
