// ===== CARGA DE PARTIALS (navbar y footer) =====
function loadPartial(selector, url, callback) {
  var el = document.querySelector(selector);
  if (!el) { if (callback) callback(); return; }
  fetch(url)
    .then(function(res) { return res.text(); })
    .then(function(html) {
      // Reemplazar {{root}} con el prefijo relativo correcto antes de insertar
      html = html.replace(/\{\{root\}\}/g, rootPrefix || '');
      el.outerHTML = html;
      if (callback) callback();
    })
    .catch(function(err) {
      console.error('Error cargando ' + url, err);
      if (callback) callback();
    });
}

function getRelativeRootPrefix() {
  // Preferido: cada página declara su propia profundidad antes de cargar este script
  // (<script>var PAGE_DEPTH = 1;</script>), independiente del entorno (Netlify, Live Server, file://).
  if (typeof PAGE_DEPTH !== 'undefined' && PAGE_DEPTH > 0) {
    return Array(PAGE_DEPTH + 1).join('../');
  }

  // Respaldo (si alguna página no define PAGE_DEPTH): estimar por la URL.
  var path = location.pathname || '';
  if (location.protocol === 'file:' && /^\/[A-Za-z]:/.test(path)) {
    path = path.slice(1);
  }
  var parts = path.split('/').filter(Boolean);
  var depth = Math.max(parts.length - 2, 0);
  return depth === 0 ? '' : Array(depth + 1).join('../');
}

var rootPrefix = getRelativeRootPrefix();
// Carga navbar → footer → luego inicializa todo el JS
loadPartial('#navbar-placeholder', rootPrefix + 'partials/navbar.html', function() {
  // ajusta enlaces raíz si se abre con file:// (fallback)
  try { window.fixRootLinks && window.fixRootLinks(); } catch(e){}
  loadPartial('#footer-placeholder', rootPrefix + 'partials/footer.html', function() {
    initApp(rootPrefix);
  });
});

// ===== TODA LA LÓGICA VA AQUÍ ADENTRO =====
function initApp(rootPrefix) {

  // ===== DARK / LIGHT MODE =====
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('edutech-theme', theme);
    var icon = document.getElementById('themeIcon');
    if (icon) {
      icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
  }
  function toggleTheme() {
    var current = document.documentElement.getAttribute('data-theme') || 'light';
    applyTheme(current === 'dark' ? 'light' : 'dark');
  }
  window.toggleTheme = toggleTheme;
  // Aplicar tema guardado al cargar
  var savedTheme = localStorage.getItem('edutech-theme') || 'light';
  applyTheme(savedTheme);

  // ===== BADGES =====
  function bounceBadge(el){
    el.style.transform='scale(1.15) translateY(-6px)';
    el.style.transition='transform 0.15s ease';
    setTimeout(function(){
      el.style.transform='scale(0.95) translateY(2px)';
      setTimeout(function(){ el.style.transform=''; },120);
    },150);
  }
  // Exponer globalmente para los onclick="bounceBadge(this)"
  window.bounceBadge = bounceBadge;

  // ===== NAV LINKS =====
  var navLinks=document.querySelectorAll('.nav-link');
  navLinks.forEach(function(link){
    link.addEventListener('click',function(){
      navLinks.forEach(function(l){ l.classList.remove('active'); });
      this.classList.add('active');
      document.getElementById('navLinks').classList.remove('open');
      document.getElementById('navBtns').classList.remove('open');
    });
  });
  var sections=document.querySelectorAll('section[id]');
  window.addEventListener('scroll',function(){
    var scrollY=window.scrollY+120;
    sections.forEach(function(sec){
      if(scrollY>=sec.offsetTop && scrollY<sec.offsetTop+sec.offsetHeight){
        var id=sec.getAttribute('id');
        navLinks.forEach(function(l){
          l.classList.remove('active');
          if(l.getAttribute('href')==='#'+id) l.classList.add('active');
        });
      }
    });
  });

  // ===== MENÚ MÓVIL =====
  function toggleMenu(){
    document.getElementById('navLinks').classList.toggle('open');
    document.getElementById('navBtns').classList.toggle('open');
  }
  window.toggleMenu = toggleMenu;

  // ===== REVEAL AL SCROLL =====
  var reveals=document.querySelectorAll('.reveal,.reveal-left,.reveal-right');
  var obs=new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting){ e.target.classList.add('visible'); obs.unobserve(e.target); }
    });
  },{threshold:0.12});
  reveals.forEach(function(el){ obs.observe(el); });

  // ===== STATS COUNTER =====
  function animateCounter(el){
    var target=parseInt(el.getAttribute('data-target'));
    var suffix=el.getAttribute('data-suffix')||'+';
    var duration=1600;
    var start=null;
    function step(ts){
      if(!start) start=ts;
      var progress=Math.min((ts-start)/duration,1);
      var ease=1-Math.pow(1-progress,3);
      el.textContent=Math.floor(ease*target)+suffix;
      if(progress<1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }
  var statObs=new IntersectionObserver(function(entries){
    entries.forEach(function(e){
      if(e.isIntersecting){
        e.target.querySelectorAll('.stat-num').forEach(animateCounter);
        statObs.unobserve(e.target);
      }
    });
  },{threshold:0.3});
  document.querySelectorAll('.stats-grid').forEach(function(el){ statObs.observe(el); });

  // ===== QUIZ =====
  var quizData=[];
  var qIndex=0, qScore=0;
  var letters=['A','B','C','D'];

  function renderQuestion(){
    var q=quizData[qIndex];
    var dots=quizData.map(function(_,i){
      var cls='q-dot';
      if(i<qIndex) cls+=' done';
      else if(i===qIndex) cls+=' active';
      return '<div class="'+cls+'"></div>';
    }).join('');
    var opts=q.opts.map(function(opt,i){
      return '<button class="q-opt" onclick="selectAnswer('+i+')" id="opt'+i+'"><span class="q-letter">'+letters[i]+'</span>'+opt+'</button>';
    }).join('');
    document.getElementById('quizInner').innerHTML=
      '<div class="quiz-progress-bar">'+dots+'</div>'+
      '<div class="quiz-q-num">Pregunta '+(qIndex+1)+' de '+quizData.length+'</div>'+
      '<div class="quiz-question">'+q.q+'</div>'+
      '<div class="quiz-options">'+opts+'</div>'+
      '<div class="quiz-feedback" id="quizFeedback"></div>';
  }

  function selectAnswer(i){
    var q=quizData[qIndex];
    var opts=document.querySelectorAll('.q-opt');
    var fb=document.getElementById('quizFeedback');
    opts.forEach(function(o){ o.classList.add('disabled'); o.style.pointerEvents='none'; });
    if(i===q.ans){
      opts[i].classList.add('correct');
      fb.innerHTML='<span class="fb-correct">✅ ¡Correcto! ¡Muy bien!</span>';
      qScore++;
    } else {
      opts[i].classList.add('wrong');
      opts[q.ans].classList.add('correct');
      fb.innerHTML='<span class="fb-wrong">❌ Casi... La respuesta era: <strong>'+q.opts[q.ans]+'</strong></span>';
    }
    setTimeout(function(){
      qIndex++;
      if(qIndex<quizData.length){ renderQuestion(); } else { showResult(); }
    },1800);
  }
  window.selectAnswer = selectAnswer;

  function showResult(){
    var emoji, title, msg;
    if(qScore===5){     emoji='🏆'; title='¡Perfecto!';         msg='Eres un genio de la computación. ¡Increíble!';}
    else if(qScore>=4){ emoji='⭐'; title='¡Excelente!';         msg='Casi perfecto. ¡Tienes un gran talento digital!';}
    else if(qScore>=3){ emoji='👍'; title='¡Buen trabajo!';      msg='Vas muy bien. ¡Un poco más de práctica y serás experto!';}
    else if(qScore>=2){ emoji='📚'; title='¡Sigue aprendiendo!'; msg='Vas por buen camino. Nuestros cursos te ayudarán mucho.';}
    else{               emoji='🚀'; title='¡Recién empezas!';    msg='No te preocupes, ¡para eso estamos aquí! Empecemos juntos.';}
    document.getElementById('quizInner').innerHTML=
      '<div class="quiz-result">'+
        '<span class="result-emoji">'+emoji+'</span>'+
        '<div class="result-title">'+title+'</div>'+
        '<div class="result-score">Obtuviste <strong>'+qScore+' de '+quizData.length+'</strong> respuestas correctas</div>'+
        '<div class="result-msg">'+msg+'</div>'+
        '<button class="btn-quiz-retry" onclick="retryQuiz()">🔄 Intentar de nuevo</button>'+
      '</div>';
  }

  function retryQuiz(){ qIndex=0; qScore=0; renderQuestion(); }
  window.retryQuiz = retryQuiz;

  if (document.getElementById('quizInner')) {
    fetch((rootPrefix || '') + 'data/quiz.json')
      .then(function(res){ return res.json(); })
      .then(function(data){ quizData=data; renderQuestion(); })
      .catch(function(err){ console.error('No se pudo cargar quiz.json:', err); });
  }

  // ===== BOTÓN ENVIAR - ContactO con EmailJS =====
  var EJ_PUBLIC_KEY  = 'F9YR2V3CNSbnu5Eo2';
  var EJ_SERVICE_ID  = 'service_edutech';
  var EJ_TEMPLATE_CONTACT = 'template_hy48vwi';
  if (typeof emailjs !== 'undefined') {
    emailjs.init({ publicKey: EJ_PUBLIC_KEY });
  }

  function mostrarMsgContacto(texto, tipo) {
    var el = document.getElementById('contactMsg');
    if (!el) return;
    el.textContent = texto;
    el.style.display = 'block';
    el.style.background = tipo === 'ok' ? '#dcfce7' : '#fee2e2';
    el.style.color      = tipo === 'ok' ? '#166534' : '#991b1b';
    el.style.border     = '1.5px solid ' + (tipo === 'ok' ? '#86efac' : '#fca5a5');
  }

  var btnSend = document.getElementById('btnSend');
  if (btnSend) {
    btnSend.addEventListener('click', function() {
      var nombre  = document.getElementById('contactNombre')  ? document.getElementById('contactNombre').value.trim()  : '';
      var email   = document.getElementById('contactEmail')   ? document.getElementById('contactEmail').value.trim()   : '';
      var mensaje = document.getElementById('contactMensaje') ? document.getElementById('contactMensaje').value.trim() : '';

      if (!nombre || !email || !mensaje) {
        mostrarMsgContacto('Por favor completa todos los campos.', 'err');
        return;
      }
      if (!email.includes('@')) {
        mostrarMsgContacto('Ingresa un correo electrónico válido.', 'err');
        return;
      }

      var btn = this;
      btn.textContent = '⏳ Enviando...';
      btn.disabled = true;

      if (typeof emailjs !== 'undefined') {
        emailjs.send(EJ_SERVICE_ID, EJ_TEMPLATE_CONTACT, {
          from_name:    nombre,
          from_email:   email,
          message:      mensaje,
          to_name:      'EduTech',
          reply_to:     email
        }).then(function() {
          btn.textContent = '✓ Mensaje enviado';
          btn.style.background = 'linear-gradient(135deg,#22c55e,#16a34a)';
          mostrarMsgContacto('✅ ¡Mensaje enviado! Te responderemos pronto.', 'ok');
          document.getElementById('contactNombre').value  = '';
          document.getElementById('contactEmail').value   = '';
          document.getElementById('contactMensaje').value = '';
          setTimeout(function() {
            btn.textContent = 'Enviar Mensaje';
            btn.style.background = '';
            btn.disabled = false;
          }, 4000);
        }).catch(function() {
          btn.textContent = 'Enviar Mensaje';
          btn.disabled = false;
          mostrarMsgContacto('❌ Error al enviar. Intenta de nuevo o escríbenos a hero.edu@outlook.com', 'err');
        });
      } else {
        // Fallback visual si EmailJS no cargó
        btn.textContent = '✓ Mensaje enviado';
        btn.style.background = 'linear-gradient(135deg,#22c55e,#16a34a)';
        mostrarMsgContacto('✅ ¡Mensaje recibido! Te responderemos pronto.', 'ok');
        setTimeout(function() {
          btn.textContent = 'Enviar Mensaje';
          btn.style.background = '';
          btn.disabled = false;
        }, 4000);
      }
    });
  }

} // fin initApp

// ===== POPUP INSCRIPCIONES =====
(function() {
  var overlay = document.getElementById('eduPopup');
  if (!overlay) return;

  // Mostrar siempre al cargar (incluso al actualizar)
  overlay.classList.remove('ep-hidden');

  // Cerrar con la X
  document.getElementById('epClose').addEventListener('click', function() {
    cerrarPopup();
  });

  // Cerrar con "Recordármelo después"
  document.getElementById('epSkip').addEventListener('click', function() {
    cerrarPopup();
  });

  // Cerrar al hacer click fuera de la tarjeta
  overlay.addEventListener('click', function(e) {
    if (e.target === overlay) cerrarPopup();
  });

  // Cerrar con tecla Escape
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') cerrarPopup();
  });

  function cerrarPopup() {
    overlay.style.animation = 'epFadeIn 0.2s ease reverse';
    setTimeout(function() {
      overlay.classList.add('ep-hidden');
    }, 180);
  }
})();
